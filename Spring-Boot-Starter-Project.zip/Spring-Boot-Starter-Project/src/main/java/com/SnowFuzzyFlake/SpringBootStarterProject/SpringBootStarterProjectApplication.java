package com.SnowFuzzyFlake.SpringBootStarterProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootStarterProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootStarterProjectApplication.class, args);
	}

}
