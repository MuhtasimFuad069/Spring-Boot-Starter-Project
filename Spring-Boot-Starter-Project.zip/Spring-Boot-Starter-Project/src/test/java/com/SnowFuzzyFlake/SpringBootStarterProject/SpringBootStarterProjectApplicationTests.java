package com.SnowFuzzyFlake.SpringBootStarterProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootStarterProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
